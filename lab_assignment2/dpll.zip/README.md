1. Enter edge data to file 'inputFront' in correct format 
2. In terminal execute command g++ frontEnd.cpp
3. ./a.out runs the program and creates file outputFront
4. Execute command g++ dpll.cpp to compile 
5. ./a.out creates file outputDpll
6. g++ backEnd.cpp 
7. ./a.out outputs solution to console